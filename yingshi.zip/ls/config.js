/**
 * 接口配置文件
 *
 * ！！！视频能否正常播放和播放有无广告的关键在于使用稳定有效的解析接口
 *
 * 如何获取解析接口请自行百度，开放使用的很多，也可以看下其他影视网站使用什么接口
 * 如希望播放时不呈现广告请自行寻找并使用无广告解析接口
 *
 * 接口不配置时会前往视频源站播放，如腾讯视频、爱奇艺等
 **/

jsApiConfig([
    "http://v.lxh5068.com/jx/?v=",
    "https://okjx.cc/?url=",
    "http://api.xdiaosi.com/?url=",
    "https://jx.70808.net/?url=",
    "https://cv.htoo.vip/?url=",
    "http://wr.wujiyy.com/?url=",
    "http://wmux.wujiyy.com/?url=",
    "http://wjmux.wujiyy.vip/xrdm/?url=",     "http://006x.vipkankan.xyz/1717yun/?url=",
    "http://006x.vipkankan.xyz/8090/?url=",  "http://wjrr.wujiyy.vip/wap/player/?url=","http://wjch.wujiyy.vip/wap/player/?url=","http://wjxc.wujiyy.vip/wap/player/?url=","http://wjym.wujiyy.vip/wap/player/?url=","https://www.mtosz.com/m3u8.php?url=","https://jx.blbo.cc:4433/?url=",
    "https://okjx.cc/?url=",
    "https://jx.973973.xyz/?url=",
    "https://api.qianqi.net/vip/?url=",
]);